# -*- coding: utf-8 -*-

# Copyright (c) 2010 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing the Restructure dialog.
"""

from __future__ import unicode_literals

from PyQt5.QtCore import pyqtSlot
from PyQt5.QtWidgets import QDialogButtonBox, QAbstractButton

from .Ui_RestructureDialog import Ui_RestructureDialog
from .RefactoringDialogBase import RefactoringDialogBase


class RestructureDialog(RefactoringDialogBase, Ui_RestructureDialog):
    """
    Class implementing the Restructure dialog.
    """
    history = None
    
    def __init__(self, refactoring, title, parent=None):
        """
        Constructor
        
        @param refactoring reference to the main refactoring object
        @type RefactoringServer
        @param title title of the dialog
        @type str
        @param parent reference to the parent widget
        @type QWidget
        """
        RefactoringDialogBase.__init__(self, refactoring, title, parent)
        self.setupUi(self)
        
        self._changeGroupName = "Restructure"
        
        self.__okButton = self.buttonBox.button(QDialogButtonBox.Ok)
        self.__okButton.setEnabled(False)
        self.__previewButton = self.buttonBox.addButton(
            self.tr("Preview"), QDialogButtonBox.ActionRole)
        self.__previewButton.setDefault(True)
        self.__previewButton.setEnabled(False)
        
        self.__loadData()
    
    def __updateUI(self):
        """
        Private slot to update the UI.
        """
        enable = bool(self.patternEdit.toPlainText()) and \
            bool(self.goalEdit.toPlainText())
        
        self.__okButton.setEnabled(enable)
        self.__previewButton.setEnabled(enable)
    
    @pyqtSlot()
    def on_patternEdit_textChanged(self):
        """
        Private slot to react to changes of the pattern.
        """
        self.__updateUI()
    
    @pyqtSlot()
    def on_goalEdit_textChanged(self):
        """
        Private slot to react to changes of the goal.
        """
        self.__updateUI()
    
    @pyqtSlot(QAbstractButton)
    def on_buttonBox_clicked(self, button):
        """
        Private slot to act on the button pressed.
        
        @param button reference to the button pressed
        @type QAbstractButton
        """
        if button == self.__previewButton:
            self.requestPreview()
        elif button == self.__okButton:
            self.applyChanges()
    
    def _calculateChanges(self):
        """
        Protected method to initiate the calculation of the changes.
        """
        self.__saveData()
        
        pattern = self.patternEdit.toPlainText()
        goal = self.goalEdit.toPlainText()
        imports = [line for line in self.importsEdit.toPlainText().splitlines()
                   if line.strip()]
        
        args = {}
        checks = self.argsEdit.toPlainText().splitlines()
        for check in checks:
            if ':' in check:
                splitted = check.split(':', 1)
                name = splitted[0].strip()
                value = splitted[1].strip()
                args[name] = value
        
        self._refactoring.sendJson("CalculateRestructureChanges", {
            "ChangeGroup": self._changeGroupName,
            "Title": self._title,
            "Pattern": pattern,
            "Goal": goal,
            "Args": args,
            "Imports": imports,
        })
    
    def __saveData(self):
        """
        Private slot to save the data for later reuse.
        """
        data = {'pattern': self.patternEdit.toPlainText(),
                'goal': self.goalEdit.toPlainText(),
                'checks': self.argsEdit.toPlainText(),
                'imports': self.importsEdit.toPlainText()
                }
        RestructureDialog.history = data

    def __loadData(self):
        """
        Private slot to load the history data into the dialog.
        """
        if RestructureDialog.history is not None:
            data = RestructureDialog.history
            self.patternEdit.setPlainText(data['pattern'])
            self.goalEdit.setPlainText(data['goal'])
            self.argsEdit.setPlainText(data['checks'])
            self.importsEdit.setPlainText(data['imports'])
