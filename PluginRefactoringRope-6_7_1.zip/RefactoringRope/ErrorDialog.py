# -*- coding: utf-8 -*-

# Copyright (c) 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing a dialog to show an error message and optionally a
traceback.
"""

from __future__ import unicode_literals

from PyQt5.QtWidgets import QDialog

from .Ui_ErrorDialog import Ui_ErrorDialog


class ErrorDialog(QDialog, Ui_ErrorDialog):
    """
    Class implementing a dialog to show an error message and optionally a
    traceback.
    """
    def __init__(self, title, errorMessage, traceback=None, parent=None):
        """
        Constructor
        
        @param title title of the dialog
        @type str
        @param errorMessage error message to be shown
        @type str
        @param traceback list of traceback entries
        @type list of str
        @param parent reference to the parent widget
        @type QWidget
        """
        super(ErrorDialog, self).__init__(parent)
        self.setupUi(self)
        
        self.tracebackEdit.hide()
        
        self.setWindowTitle(title)
        self.errorMessageLabel.setText(errorMessage)
        if traceback:
            tbIntro = self.tr("Traceback (most recent call first):\n\n")
            self.tracebackEdit.setPlainText(
                tbIntro + "\n".join(reversed(traceback)))
        else:
            self.tracebackEdit.setEnabled(False)
