# -*- coding: utf-8 -*-

# Copyright (c) 2010 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing the Add New Parameter dialog.
"""

from __future__ import unicode_literals

from PyQt5.QtCore import pyqtSlot
from PyQt5.QtWidgets import QDialog, QDialogButtonBox

from .Ui_AddParameterDialog import Ui_AddParameterDialog


class AddParameterDialog(QDialog, Ui_AddParameterDialog):
    """
    Class implementing the Add New Parameter dialog.
    """
    def __init__(self, parent=None):
        """
        Constructor
        
        @param parent reference to the parent widget
        @type QWidget
        """
        QDialog.__init__(self, parent)
        self.setupUi(self)
        
        self.__okButton = self.buttonBox.button(QDialogButtonBox.Ok)
        self.__okButton.setEnabled(False)
        
        msh = self.minimumSizeHint()
        self.resize(max(self.width(), msh.width()), msh.height())
    
    @pyqtSlot(str)
    def on_nameEdit_textChanged(self, txt):
        """
        Private slot called, when the name entry is changed.
        
        @param txt text of the entry
        @type str
        """
        self.__okButton.setEnabled(txt != "")
    
    def getData(self):
        """
        Public method to extract the data entered into the dialog.
        
        @return tuple containing name, default and value
        @rtype tuple of (str, str, str)
        """
        return (self.nameEdit.text(),
                self.defaultEdit.text(),
                self.valueEdit.text())
