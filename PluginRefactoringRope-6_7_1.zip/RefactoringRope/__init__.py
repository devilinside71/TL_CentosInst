# -*- coding: utf-8 -*-

# Copyright (c) 2010 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Package implementing the rope refactoring interface module for eric6.

This package implements just the interface for the eric6 IDE. The
refactoring is done using the rope refactoring library
(<a href="https://github.com/python-rope/rope">rope at GitHub</a>).
"""
