# -*- coding: utf-8 -*-

# Copyright (c) 2010 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing file system commands for rope.
"""

from __future__ import unicode_literals

import os


class RefactoringClientFileSystemCommands(object):
    """
    Class implementing the client side of the rope file system commands.
    """
    def __init__(self, client):
        """
        Constructor
        
        @param client reference to the refactoring client
        @type RefactoringClient
        """
        import rope.base.fscommands
        
        self.__client = client
        self.__normal_actions = rope.base.fscommands.FileSystemCommands()
    
    def create_file(self, path):
        """
        Public method called by rope to create a new file.
        
        @param path new filename
        @type str
        """
        self.__normal_actions.create_file(path)
        self.__client.sendJson("FileSystemCommand", {
            "SubCommand": "CreateFile",
            "Path": path,
        })
    
    def create_folder(self, path):
        """
        Public method called by rope to create a new directory.
        
        @param path new directory
        @type str
        """
        self.__normal_actions.create_folder(path)
        self.__client.sendJson("FileSystemCommand", {
            "SubCommand": "CreateFolder",
            "Path": path,
        })
    
    def move(self, path, new_location):
        """
        Public method called by rope to rename a file or directory.
        
        @param path old file/directory name
        @type str
        @param new_location new file/directory name
        @type str
        """
        self.__client.sendJson("FileSystemCommand", {
            "SubCommand": "Move",
            "Path": path,
            "NewLocation": new_location,
        })
    
    def remove(self, path):
        """
        Public method called by rope to remove a file or directory.
        
        @param path name of file/directory to remove
        @type str
        """
        self.__normal_actions.remove(path)
        self.__client.sendJson("FileSystemCommand", {
            "SubCommand": "Remove",
            "Path": path,
        })
    
    def write(self, path, data):
        """
        Public method called by rope to write data to a file.
        
        @param path filename of file to write to
        @type str
        @param data data to be written
        """
        self.__normal_actions.write(path, data)


class E5FileSystemCommands(object):
    """
    Class implementing file system commands for rope.
    """
    def __init__(self, project):
        """
        Constructor
        
        @param project reference to the eric project object
        @type Project.Project
        """
        self.__project = project
    
    def processFileSystemCommand(self, params):
        """
        Public method to process rope file system commands.
        
        @param params dictionary containing the command and relevant data
        @type dict
        """
        command = params["SubCommand"]
        
        if command == "CreateFile":
            self.__createFile(params["Path"])
        
        elif command == "CreateFolder":
            self.__createFolder(params["Path"])
        
        elif command == "Move":
            self.__move(params["Path"], params["NewLocation"])
        
        elif command == "Remove":
            self.__remove(params["Path"])
    
    def __createFile(self, path):
        """
        Private method called by rope to create a new file.
        
        @param path new filename
        @type str
        """
        self.__project.appendFile(path)
        vcs = self.__project.getVcs()
        if vcs is not None:
            vcs.vcsAdd(path, noDialog=True)
    
    def __createFolder(self, path):
        """
        Private method called by rope to create a new directory.
        
        @param path new directory
        @type str
        """
        vcs = self.__project.getVcs()
        if vcs is not None:
            vcs.vcsAdd(path, noDialog=True)
    
    def __move(self, path, new_location):
        """
        Private method called by rope to rename a file or directory.
        
        @param path old file/directory name
        @type str
        @param new_location new file/directory name
        @type str
        """
        vcs = self.__project.getVcs()
        if vcs is None:
            if os.path.isdir(path):
                self.__project.moveDirectory(path, new_location)
            else:
                self.__project.renameFile(path, new_location)
        else:
            vcs.vcsMove(path, self.__project, new_location, noDialog=True)
    
    def __remove(self, path):
        """
        Private method called by rope to remove a file or directory.
        
        @param path name of file/directory to remove (string)
        """
        vcs = self.__project.getVcs()
        if vcs is None:
            if os.path.isdir(path):
                self.__project.removeDirectory(path)
            else:
                from E5Gui.E5Application import e5App
                e5App().getObject("ViewManager").closeWindow(path)
                self.__project.removeFile(path)
        else:
            vcs.vcsRemove(path, noDialog=True)
