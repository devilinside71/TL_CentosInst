# -*- coding: utf-8 -*-

# Copyright (c) 2010 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing the Rename dialog.
"""

from __future__ import unicode_literals

from PyQt5.QtCore import pyqtSlot
from PyQt5.QtWidgets import QDialogButtonBox, QAbstractButton

from E5Gui.E5Application import e5App
from E5Gui import E5MessageBox

from .Ui_RenameDialog import Ui_RenameDialog
from .RefactoringDialogBase import RefactoringDialogBase


class RenameDialog(RefactoringDialogBase, Ui_RenameDialog):
    """
    Class implementing the Rename dialog.
    """
    def __init__(self, refactoring, title, filename, offset, isLocal,
                 selectedText='', parent=None):
        """
        Constructor
        
        @param refactoring reference to the main refactoring object
        @type RefactoringServer
        @param title title of the dialog
        @type str
        @param filename file name to be worked on
        @type str
        @param offset offset within file
        @type int or None
        @param isLocal flag indicating to restrict refactoring to
            the local file
        @type bool
        @param selectedText selected text to rename
        @type str
        @param parent reference to the parent widget
        @type QWidget
        """
        RefactoringDialogBase.__init__(self, refactoring, title, parent)
        self.setupUi(self)
        
        self._changeGroupName = "Rename"
        
        self.__filename = filename
        self.__offset = offset
        self.__local = isLocal
        
        self.__okButton = self.buttonBox.button(QDialogButtonBox.Ok)
        self.__okButton.setEnabled(False)
        self.__previewButton = self.buttonBox.addButton(
            self.tr("Preview"), QDialogButtonBox.ActionRole)
        self.__previewButton.setDefault(True)
        self.__previewButton.setEnabled(False)
        
        self.newNameEdit.setText(selectedText)
        self.newNameEdit.selectAll()
        
        msh = self.minimumSizeHint()
        self.resize(max(self.width(), msh.width()), msh.height())
    
    @pyqtSlot(str)
    def on_newNameEdit_textChanged(self, text):
        """
        Private slot to react to changes of the new name.
        
        @param text text entered into the edit
        @type str
        """
        self.__okButton.setEnabled(text != "")
        self.__previewButton.setEnabled(text != "")
    
    @pyqtSlot(QAbstractButton)
    def on_buttonBox_clicked(self, button):
        """
        Private slot to act on the button pressed.
        
        @param button reference to the button pressed
        @type QAbstractButton
        """
        if button == self.__previewButton:
            self.requestPreview()
        elif button == self.__okButton:
            self.applyChanges()
    
    def __confirmUnsure(self, data):
        """
        Private method to confirm unsure occurrences.
        
        @param data dictionary containing the change data
        @type dict
        """
        if self.ignoreButton.isChecked():
            answer = False
        elif self.matchButton.isChecked():
            answer = True
        else:
            filename = data["FileName"]
            start = data["StartOffset"]
            end = data["EndOffset"]
            
            vm = e5App().getObject("ViewManager")
            
            # display the file and select the match
            vm.openSourceFile(filename)
            aw = vm.activeWindow()
            cline, cindex = aw.getCursorPosition()
            sline, sindex = aw.lineIndexFromPosition(start)
            eline, eindex = aw.lineIndexFromPosition(end)
            aw.ensureLineVisible(sline)
            aw.gotoLine(sline)
            aw.setSelection(sline, sindex, eline, eindex)
            
            answer = E5MessageBox.yesNo(
                self._ui,
                self.tr("Rename"),
                self.tr("""<p>Is the highlighted code a match?</p>"""),
                yesDefault=True)
            
            aw.setCursorPosition(cline, cindex)
            aw.ensureCursorVisible()
        
        self._refactoring.sendJson("ConfirmUnsure", {
            "Answer": answer,
        })
    
    def _calculateChanges(self):
        """
        Protected method to initiate the calculation of the changes.
        """
        if self.askButton.isChecked():
            self.hide()
        
        self._refactoring.sendJson("CalculateRenameChanges", {
            "ChangeGroup": self._changeGroupName,
            "Title": self._title,
            "FileName": self.__filename,
            "Offset": self.__offset,
            "LocalRename": self.__local,
            "NewName": self.newNameEdit.text(),
            "RenameHierarchy": self.allCheckBox.isChecked(),
            "RenameInStrings": self.stringsCheckBox.isChecked(),
        })
    
    def processChangeData(self, data):
        """
        Public method to process the change data sent by the refactoring
        client.
        
        @param data dictionary containing the change data
        @type dict
        """
        subcommand = data["Subcommand"]
        if subcommand == "ConfirmUnsure":
            self.__confirmUnsure(data)
        else:
            # pass on to base class
            RefactoringDialogBase.processChangeData(self, data)
