# -*- coding: utf-8 -*-

# Copyright (c) 2017 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing a TaskHandle class with a progress dialog.
"""

from __future__ import unicode_literals

from PyQt5.QtCore import QCoreApplication
from PyQt5.QtWidgets import QLabel

from E5Gui.E5ProgressDialog import E5ProgressDialog


class RopeProgressDialog(E5ProgressDialog):
    """
    Class implementing TaskHandle with a progress dialog.
    """
    def __init__(self, server, title, interruptable=True, parent=None):
        """
        Constructor
        
        @param server reference to the JSON server
        @type JsonServer
        @param title title for the dialog
        @type str
        @param interruptable flag indicating, that the task may be
            interrupted
        @type bool
        @param parent reference to the parent widget
        @type QWidget
        """
        super(RopeProgressDialog, self).__init__("", "", 0, 1,
                                                 "", parent)
        if interruptable:
            self.setCancelButtonText(self.tr("Interrupt"))
        self.setFormat(self.tr("%v/%m files"))
        label = QLabel("")
        label.setWordWrap(True)
        self.setLabel(label)
        self.setWindowTitle(self.tr("eric6 - {0}").format(title))
        
        self.__server = server
    
    def updateProgress(self, params):
        """
        Public slot to handle the task progress.
        
        @param params dictionary containing the data to be set
        @type dict
        """
        if params:
            self.setLabelText(params["Text"])
        if "Maximum" in params:
            # these are always sent together
            self.setMaximum(params["Maximum"])
            self.setValue(params["Value"])
        
        QCoreApplication.processEvents()
        
        if self.wasCanceled():
            self.__server.sendJson("AbortAction", {})
