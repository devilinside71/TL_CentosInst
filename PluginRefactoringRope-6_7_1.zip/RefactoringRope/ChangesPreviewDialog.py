# -*- coding: utf-8 -*-

# Copyright (c) 2010 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing the Changes preview dialog.
"""

from __future__ import unicode_literals

from PyQt5.QtCore import Qt, pyqtSlot
from PyQt5.QtWidgets import QDialogButtonBox, QListWidgetItem

from .PreviewDialogBase import PreviewDialogBase


class ChangesPreviewDialog(PreviewDialogBase):
    """
    Class implementing the Changes preview dialog.
    """
    ChangeRole = Qt.UserRole
    
    def __init__(self, description, changes, parent):
        """
        Constructor
        
        @param description description of the changes
        @type str
        @param changes list of lists containing the change data
        @type list of list of (str, str)
        @param parent reference to the parent widget
        @type QWidget
        """
        PreviewDialogBase.__init__(self, parent)
        
        self.buttonBox.addButton(
            self.tr("&Apply Changes"), QDialogButtonBox.AcceptRole)
        self.buttonBox.addButton(QDialogButtonBox.Cancel)
        
        self.description.setText(description)
        for changeTitle, changeText in changes:
            itm = QListWidgetItem(changeTitle, self.changesList)
            if changeText is None:
                changeText = self.tr("No changes available.")
            itm.setData(ChangesPreviewDialog.ChangeRole, changeText)
        if self.changesList.count():
            self.changesList.item(0).setSelected(True)
    
    @pyqtSlot(QListWidgetItem, QListWidgetItem)
    def on_changesList_currentItemChanged(self, current, previous):
        """
        Private slot called when a change is selected.
        
        @param current reference to the new current item
        @type QListWidgetItem
        @param previous reference to the old current item
        @type QListWidgetItem
        """
        if current is None:
            return
        
        self.previewEdit.clear()
        for line in current.data(ChangesPreviewDialog.ChangeRole)\
                .splitlines(True):
            try:
                charFormat = self.formats[line[0]]
            except (IndexError, KeyError):
                charFormat = self.formats[' ']
            self._appendText(line, charFormat)
