# -*- coding: utf-8 -*-

# Copyright (c) 2010 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing the Use Function dialog.
"""

from __future__ import unicode_literals

from PyQt5.QtCore import pyqtSlot
from PyQt5.QtWidgets import QDialogButtonBox, QAbstractButton

from .Ui_UseFunctionDialog import Ui_UseFunctionDialog
from .RefactoringDialogBase import RefactoringDialogBase


class UseFunctionDialog(RefactoringDialogBase, Ui_UseFunctionDialog):
    """
    Class implementing the Use Function dialog.
    """
    def __init__(self, refactoring, title, filename, offset, parent=None):
        """
        Constructor
        
        @param refactoring reference to the main refactoring object
        @type RefactoringServer
        @param title title of the dialog
        @type str
        @param filename file name to be worked on
        @type str
        @param offset offset within file
        @type int or None
        @param parent reference to the parent widget
        @type QWidget
        """
        RefactoringDialogBase.__init__(self, refactoring, title, parent)
        self.setupUi(self)
        
        self._changeGroupName = "UseFunction"
        
        self.__filename = filename
        self.__offset = offset
        
        self.__okButton = self.buttonBox.button(QDialogButtonBox.Ok)
        self.__previewButton = self.buttonBox.addButton(
            self.tr("Preview"), QDialogButtonBox.ActionRole)
        self.__previewButton.setDefault(True)
        
        self._refactoring.sendJson("RequestUseFunction", {
            "ChangeGroup": self._changeGroupName,
            "Title": self._title,
            "FileName": self.__filename,
            "Offset": self.__offset,
        })
    
    def __processUseFunctionName(self, data):
        """
        Private method to process the function name data sent by the
        refactoring client in order to polish the dialog.
        
        @param data dictionary containing the inline type data
        @type dict
        """
        self.description.setText(
            self.tr("Using Function <b>{0}</b>.")
                .format(data["FunctionName"]))
        
        if not data["FunctionName"]:
            self.__okButton.setEnabled(False)
            self.__previewButton.setEnabled(False)
        
        msh = self.minimumSizeHint()
        self.resize(max(self.width(), msh.width()), msh.height())
    
    @pyqtSlot(QAbstractButton)
    def on_buttonBox_clicked(self, button):
        """
        Private slot to act on the button pressed.
        
        @param button reference to the button pressed
        @type QAbstractButton
        """
        if button == self.__previewButton:
            self.requestPreview()
        elif button == self.__okButton:
            self.applyChanges()
    
    def _calculateChanges(self):
        """
        Protected method to initiate the calculation of the changes.
        """
        self._refactoring.sendJson("CalculateUseFunctionChanges", {
            "ChangeGroup": self._changeGroupName,
            "Title": self._title,
            "FileName": self.__filename,
            "Offset": self.__offset,
        })
    
    def processChangeData(self, data):
        """
        Public method to process the change data sent by the refactoring
        client.
        
        @param data dictionary containing the change data
        @type dict
        """
        subcommand = data["Subcommand"]
        if subcommand == "UseFunctionName":
            self.__processUseFunctionName(data)
        else:
            # pass on to base class
            RefactoringDialogBase.processChangeData(self, data)
