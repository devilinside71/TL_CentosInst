# -*- coding: utf-8 -*-

# Copyright (c) 2010 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing a dialog base class to preview changes.
"""

from __future__ import unicode_literals

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QBrush, QColor, QTextCursor
from PyQt5.QtWidgets import QDialog

from .Ui_PreviewDialog import Ui_PreviewDialog

import Globals


class PreviewDialogBase(QDialog, Ui_PreviewDialog):
    """
    Class implementing a dialog base class to preview changes.
    """
    def __init__(self, parent=None):
        """
        Constructor
        
        @param parent reference to the parent widget
        @type QWidget
        """
        QDialog.__init__(self, parent)
        self.setAttribute(Qt.WA_DeleteOnClose)
        self.setupUi(self)
        
        if Globals.isWindowsPlatform():
            self.previewEdit.setFontFamily("Lucida Console")
        else:
            self.previewEdit.setFontFamily("Monospace")
        
        self.formats = {}
        self.formats[' '] = self.previewEdit.currentCharFormat()
        charFormat = self.previewEdit.currentCharFormat()
        charFormat.setBackground(QBrush(QColor(190, 237, 190)))
        self.formats['+'] = charFormat
        charFormat = self.previewEdit.currentCharFormat()
        charFormat.setBackground(QBrush(QColor(237, 190, 190)))
        self.formats['-'] = charFormat
        charFormat = self.previewEdit.currentCharFormat()
        charFormat.setBackground(QBrush(QColor(190, 190, 237)))
        self.formats['@'] = charFormat
        charFormat = self.previewEdit.currentCharFormat()
        charFormat.setBackground(QBrush(QColor(124, 124, 124)))
        self.formats['?'] = charFormat
        charFormat = self.previewEdit.currentCharFormat()
        charFormat.setBackground(QBrush(QColor(190, 190, 190)))
        self.formats['='] = charFormat
    
    def _appendText(self, txt, charFormat):
        """
        Protected method to append text to the end of the contents pane.
        
        @param txt text to insert
        @type str
        @param charFormat text format to be used
        @type QTextCharFormat
        """
        tc = self.previewEdit.textCursor()
        tc.movePosition(QTextCursor.End)
        self.previewEdit.setTextCursor(tc)
        self.previewEdit.setCurrentCharFormat(charFormat)
        self.previewEdit.insertPlainText(txt)
