# -*- coding: utf-8 -*-

# Copyright (c) 2010 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing a dialog to show matching references/definitions.
"""

from __future__ import unicode_literals

from PyQt5.QtCore import pyqtSlot, Qt
from PyQt5.QtWidgets import QDialog, QTreeWidgetItem, QDialogButtonBox, \
    QHeaderView

from E5Gui.E5Application import e5App

from .Ui_MatchesDialog import Ui_MatchesDialog


class MatchesDialog(QDialog, Ui_MatchesDialog):
    """
    Class implementing a dialog to show matching references/definitions.
    """
    FilePathRole = Qt.UserRole
    
    def __init__(self, ui, showConfidence, parent=None, name=None):
        """
        Constructor
        
        @param ui reference to the UI object
        @type UI.UserInterface
        @param showConfidence flag indicating the display of the
            confidence column
        @type bool
        @param parent parent of this dialog
        @type QWidget
        @param name name of this dialog
        @type str
        """
        QDialog.__init__(self, parent)
        if name:
            self.setObjectName(name)
        self.setupUi(self)
        
        self.buttonBox.button(QDialogButtonBox.Close).setDefault(True)
        
        self.ui = ui
        self.__showConfidence = showConfidence
        self.__e5project = e5App().getObject("Project")
        
        if not self.__showConfidence:
            self.matchesList.setColumnHidden(2, True)
        self.matchesList.header().setSortIndicator(0, Qt.AscendingOrder)
    
    def __resort(self):
        """
        Private method to resort the tree.
        """
        self.matchesList.sortItems(
            self.matchesList.sortColumn(),
            self.matchesList.header().sortIndicatorOrder())
    
    def __resizeColumns(self):
        """
        Private method to resize the list columns.
        """
        self.matchesList.header().resizeSections(QHeaderView.ResizeToContents)
        self.matchesList.header().setStretchLastSection(True)
    
    @pyqtSlot(QTreeWidgetItem, int)
    def on_matchesList_itemActivated(self, item, column):
        """
        Private slot to handle the itemActivated signal of the list.
        
        @param item reference to the activated item
        @type QTreeWidgetItem
        @param column column the item was activated in
        @type int
        """
        lineno = int(item.text(1))
        fn = item.data(0, MatchesDialog.FilePathRole)
        e5App().getObject("ViewManager").openSourceFile(fn, lineno)
    
    def addEntry(self, filename, lineno, unsure=False):
        """
        Public slot to add an entry to the list.
        
        @param filename full path of the matched file
        @type str
        @param lineno line number of the match
        @type int
        @param unsure flag indicating an unsure match
        @type bool
        """
        if unsure:
            conf = 50
        else:
            conf = 100
        itm = QTreeWidgetItem(
            self.matchesList,
            [self.__e5project.getRelativePath(filename),
             " {0:5d}".format(lineno),
             " {0:5d}%".format(conf)])
        itm.setData(0, MatchesDialog.FilePathRole, filename)
        itm.setTextAlignment(1, Qt.AlignRight)
        itm.setTextAlignment(2, Qt.AlignRight)
        self.__resort()
        self.__resizeColumns()
