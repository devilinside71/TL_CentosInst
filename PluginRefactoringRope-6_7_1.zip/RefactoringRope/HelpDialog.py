# -*- coding: utf-8 -*-

# Copyright (c) 2010 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing a dialog to show help about rope.
"""

from __future__ import unicode_literals

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QTextDocument, QTextCursor
from PyQt5.QtWidgets import QDialog, QDialogButtonBox

from .Ui_HelpDialog import Ui_HelpDialog

import Globals


class HelpDialog(QDialog, Ui_HelpDialog):
    """
    Class implementing a dialog to show help about rope.
    """
    def __init__(self, title, helpfile, parent=None):
        """
        Constructor
        
        @param title window title
        @type str
        @param helpfile filename of the helpfile
        @type str
        @param parent reference to the parent widget
        @type QWidget
        """
        QDialog.__init__(self, parent)
        self.setupUi(self)
        self.setWindowFlags(Qt.Window)
        
        self.searchButton = self.buttonBox.addButton(
            self.tr("Search..."), QDialogButtonBox.ActionRole)
        self.__searchDlg = None
        
        if Globals.isWindowsPlatform():
            self.helpEdit.setFontFamily("Lucida Console")
        else:
            self.helpEdit.setFontFamily("Monospace")
        
        try:
            f = open(helpfile, "r", encoding="utf-8")
            txt = f.read()
            f.close()
            self.helpEdit.setPlainText(txt)
        except IOError as err:
            self.helpEdit.setPlainText(
                self.tr("Could not read file {0}.\nReason: {1}")
                    .format(helpfile, str(err)))

    def on_buttonBox_clicked(self, button):
        """
        Private slot called by a button of the button box clicked.
        
        @param button button that was clicked
        @type QAbstractButton
        """
        if button == self.searchButton:
            if self.__searchDlg is None:
                from .SearchDialog import SearchDialog
                self.__searchDlg = SearchDialog(self)
            self.__searchDlg.showFind()
    
    def findNextPrev(self, txt, case, word, backwards):
        """
        Public slot to find the next occurrence of a text.
        
        @param txt text to search for
        @type str
        @param case flag indicating a case sensitive search
        @type bool
        @param word flag indicating a word based search
        @type bool
        @param backwards flag indicating a backwards search
        @type bool
        @return flag indicating the search found another occurrence
        @rtype bool
        """
        doc = self.helpEdit.document()
        cur = self.helpEdit.textCursor()
        
        findFlags = QTextDocument.FindFlags()
        if case:
            findFlags |= QTextDocument.FindCaseSensitively
        if word:
            findFlags |= QTextDocument.FindWholeWords
        if backwards:
            findFlags |= QTextDocument.FindBackward
        
        if cur.hasSelection():
            cur.setPosition(backwards and cur.anchor() or cur.position(),
                            QTextCursor.MoveAnchor)
        newCur = doc.find(txt, cur, findFlags)
        if newCur.isNull():
            return False
        else:
            self.helpEdit.setTextCursor(newCur)
            return True
    
    def helpWidget(self):
        """
        Public method to get a reference to the help widget.
        
        @return reference to the help widget
        @rtype QTextEdit
        """
        return self.helpEdit
