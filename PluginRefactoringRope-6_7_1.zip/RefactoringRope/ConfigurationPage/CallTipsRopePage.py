# -*- coding: utf-8 -*-

# Copyright (c) 2008 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing the Rope Calltips configuration page.
"""

from __future__ import unicode_literals

from Preferences.ConfigurationPages.ConfigurationPageBase import \
    ConfigurationPageBase
from .Ui_CallTipsRopePage import Ui_CallTipsRopePage


class CallTipsRopePage(ConfigurationPageBase, Ui_CallTipsRopePage):
    """
    Class implementing the Rope Calltips configuration page.
    """
    def __init__(self, plugin):
        """
        Constructor
        
        @param plugin reference to the plugin object
        @type RefactoringRopePlugin
        """
        ConfigurationPageBase.__init__(self)
        self.setupUi(self)
        self.setObjectName("CallTipsRopePage")
        
        self.__plugin = plugin
        
        # set initial values
        self.ropeCalltipsCheckBox.setChecked(
            self.__plugin.getPreferences("CodeAssistCalltipsEnabled"))
        self.ctMaxfixesSpinBox.setValue(
            self.__plugin.getPreferences("CalltipsMaxFixes"))
        
    def save(self):
        """
        Public slot to save the Rope Calltips configuration.
        """
        self.__plugin.setPreferences(
            "CodeAssistCalltipsEnabled", self.ropeCalltipsCheckBox.isChecked())
        self.__plugin.setPreferences(
            "CalltipsMaxFixes", self.ctMaxfixesSpinBox.value())
