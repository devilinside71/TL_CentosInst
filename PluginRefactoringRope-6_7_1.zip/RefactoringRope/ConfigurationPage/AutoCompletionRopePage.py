# -*- coding: utf-8 -*-

# Copyright (c) 2008 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing the Rope Autocompletion configuration page.
"""

from __future__ import unicode_literals

from PyQt5.QtCore import pyqtSlot

from Preferences.ConfigurationPages.ConfigurationPageBase import \
    ConfigurationPageBase
from .Ui_AutoCompletionRopePage import Ui_AutoCompletionRopePage


class AutoCompletionRopePage(ConfigurationPageBase, Ui_AutoCompletionRopePage):
    """
    Class implementing the Rope Autocompletion configuration page.
    """
    def __init__(self, plugin):
        """
        Constructor
        
        @param plugin reference to the plugin object
        @type RefactoringRopePlugin
        """
        ConfigurationPageBase.__init__(self)
        self.setupUi(self)
        self.setObjectName("AutoCompletionRopePage")
        
        self.__plugin = plugin
        
        # set initial values
        self.ropeAutocompletionCheckBox.setChecked(
            self.__plugin.getPreferences("CodeAssistEnabled"))
        self.acMaxfixesSpinBox.setValue(
            self.__plugin.getPreferences("MaxFixes"))
        
    def save(self):
        """
        Public slot to save the Rope Autocompletion configuration.
        """
        self.__plugin.setPreferences(
            "CodeAssistEnabled", self.ropeAutocompletionCheckBox.isChecked())
        self.__plugin.setPreferences(
            "MaxFixes", self.acMaxfixesSpinBox.value())

    def polishPage(self):
        """
        Public slot to perform some polishing actions.
        """
        names = self.__plugin.getCodeAssistServer().connectionNames()
        self.python2Button.setEnabled("Python2" in names)
        self.python3Button.setEnabled("Python3" in names)
    
    @pyqtSlot()
    def on_python2Button_clicked(self):
        """
        Private slot to edit the rope configuration for Python 2.
        """
        self.__plugin.getCodeAssistServer().editConfig("Python2")
    
    @pyqtSlot()
    def on_python3Button_clicked(self):
        """
        Private slot to edit the rope configuration for Python 3.
        """
        self.__plugin.getCodeAssistServer().editConfig("Python3")
