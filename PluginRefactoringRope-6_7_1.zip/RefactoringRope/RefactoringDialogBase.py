# -*- coding: utf-8 -*-

# Copyright (c) 2010 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing the Refactoring dialog base class.
"""

from __future__ import unicode_literals

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QDialog

from E5Gui.E5Application import e5App


class RefactoringDialogBase(QDialog):
    """
    Class implementing the Refactoring dialog base class.
    """
    def __init__(self, refactoring, title, parent=None):
        """
        Constructor
        
        @param refactoring reference to the main refactoring object
        @type RefactoringServer
        @param title title of the dialog
        @type str
        @param parent reference to the parent widget
        @type QWidget
        """
        QDialog.__init__(self, parent)
        self.setAttribute(Qt.WA_DeleteOnClose)
        self.setWindowTitle(title)
        
        self._ui = parent
        self._refactoring = refactoring
        self._title = title
        
        self._changesCalculated = False
        
        self.__queue = []
    
    def getChangeGroupName(self):
        """
        Public method to get the name of the change group.
        
        @return name of the associated change group
        @rtype str
        """
        return self._changeGroupName
    
    def _calculateChanges(self):
        """
        Protected method to initiate the calculation of changes.
        
        @exception NotImplementedError raised to indicate that this method must
            be overridden by subclasses
        """
        raise NotImplementedError("_calculateChanges must be overridden.")
    
    def requestPreview(self):
        """
        Public method to request a preview of the calculated changes.
        """
        self.__queue.append(("PreviewChanges", {
            "ChangeGroup": self._changeGroupName,
        }))
        
        self._calculateChanges()
    
    def previewChanges(self, data):
        """
        Public method to preview the changes.
        
        @param data dictionary containing the change data
        @type dict
        """
        from .ChangesPreviewDialog import ChangesPreviewDialog
        dlg = ChangesPreviewDialog(
            data["Description"], data["Changes"], self)
        if dlg.exec_() == QDialog.Accepted:
            self.applyChanges()
    
    def applyChanges(self):
        """
        Public method to apply the changes.
        """
        if not self._changesCalculated:
            self.__queue.append(("ApplyChanges", {
                "ChangeGroup": self._changeGroupName,
                "Title": self._title,
            }))
            self._calculateChanges()
        else:
            self._refactoring.sendJson("ApplyChanges", {
                "ChangeGroup": self._changeGroupName,
                "Title": self._title,
            })
    
    def processChangeData(self, data):
        """
        Public method to process the change data sent by the refactoring
        client.
        
        @param data dictionary containing the change data
        @type dict
        """
        subcommand = data["Subcommand"]
        if subcommand == "PreviewChanges":
            self.previewChanges(data)
        elif subcommand == "ChangesCalculated":
            self._changesCalculated = True
            if not self.isVisible():
                self.show()
            if self.__queue:
                method, params = self.__queue.pop(0)
                self._refactoring.sendJson(method, params)
        elif subcommand == "ChangesApplied":
            if self._refactoring.handleRopeError(data):
                self._refactoring.refreshEditors(data["ChangedFiles"])
                p = e5App().getObject("Project")
                if p.isDirty():
                    p.saveProject()
            
            self.accept()
    
    def closeEvent(self, evt):
        """
        Protected method handling close events.
        
        @param evt reference to the close event object
        @type QCloseEvent
        """
        self._refactoring.sendJson("ClearChanges", {
            "ChangeGroup": self._changeGroupName,
        })
        
        evt.accept()
