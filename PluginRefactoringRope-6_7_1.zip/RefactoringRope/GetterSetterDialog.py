# -*- coding: utf-8 -*-

# Copyright (c) 2010 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing the encapsulate attribute dialog.
"""

from __future__ import unicode_literals

from PyQt5.QtCore import pyqtSlot
from PyQt5.QtWidgets import QDialogButtonBox, QAbstractButton

from .Ui_GetterSetterDialog import Ui_GetterSetterDialog
from .RefactoringDialogBase import RefactoringDialogBase


class GetterSetterDialog(RefactoringDialogBase, Ui_GetterSetterDialog):
    """
    Class implementing the encapsulate attribute dialog.
    """
    def __init__(self, refactoring, title, filename, offset, parent=None):
        """
        Constructor
        
        @param refactoring reference to the main refactoring object
        @type RefactoringServer
        @param title title of the dialog
        @type str
        @param filename file name to be worked on
        @type str
        @param offset offset within file
        @type int or None
        @param parent reference to the parent widget
        @type QWidget
        """
        RefactoringDialogBase.__init__(self, refactoring, title, parent)
        self.setupUi(self)
        
        self._changeGroupName = "GetterSetter"
        
        self.__filename = filename
        self.__offset = offset
        
        self.__okButton = self.buttonBox.button(QDialogButtonBox.Ok)
        self.__okButton.setEnabled(False)
        self.__previewButton = self.buttonBox.addButton(
            self.tr("Preview"), QDialogButtonBox.ActionRole)
        self.__previewButton.setDefault(True)
        self.__previewButton.setEnabled(False)
        
        self.__fieldName = ""
        
        self._refactoring.sendJson("RequestFieldName", {
            "ChangeGroup": self._changeGroupName,
            "Title": self._title,
            "FileName": self.__filename,
            "Offset": self.__offset,
        })
    
    def __processFieldName(self, data):
        """
        Private method to process the field name data sent by the refactoring
        client in order to polish the dialog.
        
        @param data dictionary containing the inline type data
        @type dict
        """
        self.__fieldName = data["Name"]
        
        self.on_typeCheckBox_toggled(False)
        
        msh = self.minimumSizeHint()
        self.resize(max(self.width(), msh.width()), msh.height())
    
    def __updateUI(self):
        """
        Private slot to update the UI.
        """
        enable = bool(self.getterEdit.text()) and bool(self.setterEdit.text())
        
        self.__okButton.setEnabled(enable)
        self.__previewButton.setEnabled(enable)
    
    @pyqtSlot(str)
    def on_getterEdit_textChanged(self, text):
        """
        Private slot to react to changes of the getter method.
        
        @param text text entered into the edit
        @type str
        """
        self.__updateUI()
    
    @pyqtSlot(str)
    def on_setterEdit_textChanged(self, text):
        """
        Private slot to react to changes of the setter method.
        
        @param text text entered into the edit
        @type str
        """
        self.__updateUI()
    
    @pyqtSlot(bool)
    def on_typeCheckBox_toggled(self, checked):
        """
        Private slot to react to changes of the type checkbox.
        
        @param checked state of the checkbox
        @type bool
        """
        if checked:
            self.getterEdit.setText("get_{0}".format(self.__fieldName))
            self.setterEdit.setText("set_{0}".format(self.__fieldName))
        else:
            self.getterEdit.setText(
                "get{0}".format(self.__fieldName.capitalize()))
            self.setterEdit.setText(
                "set{0}".format(self.__fieldName.capitalize()))
    
    @pyqtSlot(QAbstractButton)
    def on_buttonBox_clicked(self, button):
        """
        Private slot to act on the button pressed.
        
        @param button reference to the button pressed
        @type QAbstractButton
        """
        if button == self.__previewButton:
            self.requestPreview()
        elif button == self.__okButton:
            self.applyChanges()
    
    def _calculateChanges(self):
        """
        Protected method to initiate the calculation of the changes.
        """
        self._refactoring.sendJson("CalculateEncapsulateFieldChanges", {
            "ChangeGroup": self._changeGroupName,
            "Title": self._title,
            "FileName": self.__filename,
            "Offset": self.__offset,
            "Getter": self.getterEdit.text(),
            "Setter": self.setterEdit.text(),
        })
    
    def processChangeData(self, data):
        """
        Public method to process the change data sent by the refactoring
        client.
        
        @param data dictionary containing the change data
        @type dict
        """
        subcommand = data["Subcommand"]
        if subcommand == "FieldName":
            self.__processFieldName(data)
        else:
            # pass on to base class
            RefactoringDialogBase.processChangeData(self, data)
