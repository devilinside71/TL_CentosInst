# -*- coding: utf-8 -*-

# Copyright (c) 2010 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing a distributed TaskHandle class with a progress dialog.
"""

from __future__ import unicode_literals

import rope.base.taskhandle


class ProgressHandle(rope.base.taskhandle.TaskHandle):
    """
    Class implementing distributed TaskHandle with a progress dialog.
    
    This is the client side.
    """
    def __init__(self, client, title, interruptable=True):
        """
        Constructor
        
        @param client reference to the JSON client
        @type JsonClient
        @param title title for the taskhandle
        @type str
        @param interruptable flag indicating, that the task may be
            interrupted
        @type bool
        """
        rope.base.taskhandle.TaskHandle.__init__(self, title, interruptable)
        
        self.__client = client
        
        self.__client.sendJson("Progress", {
            "Subcommand": "Init",
            "Title": title,
            "Interruptable": interruptable,
        })
        
        self.add_observer(self.__updateProgress)
    
    def __updateProgress(self):
        """
        Private slot to handle the task progress.
        """
        params = {
            "Subcommand": "Progress",
        }
        
        jobset = self.current_jobset()
        if jobset:
            text = ''
            if jobset.get_name() is not None:
                text += jobset.get_name()
            if jobset.get_active_job_name() is not None:
                text += ': ' + jobset.get_active_job_name()
            params["Text"] = text
            if jobset.count is not None:
                params["Maximum"] = jobset.count
                params["Value"] = jobset.done
        
        self.__client.sendJson("Progress", params)
        self.__client.poll()
    
    def reset(self):
        """
        Public slot to reset the progress dialog.
        """
        self.__client.sendJson("Progress", {
            "Subcommand": "Reset",
        })
        self.__client.poll()
