# -*- coding: utf-8 -*-

# Copyright (c) 2010 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing the search dialog for the rope help dialog.
"""

from __future__ import unicode_literals

from PyQt5.QtCore import pyqtSlot, Qt
from PyQt5.QtWidgets import QDialog, QDialogButtonBox

from E5Gui import E5MessageBox

from .Ui_SearchDialog import Ui_SearchDialog


class SearchDialog(QDialog, Ui_SearchDialog):
    """
    Module implementing the search dialog for the rope help dialog.
    """
    def __init__(self, parent=None, name="", fl=Qt.Widget):
        """
        Constructor
        
        @param parent parent widget of this dialog
        @type QWidget
        @param name object name of the dialog
        @type str
        @param fl window flags
        @type Qt.WindowFlags
        """
        QDialog.__init__(self, parent, fl)
        self.setupUi(self)
        self.setObjectName(name)
        self.setWindowFlags(Qt.Window)
        
        self.findButton = self.buttonBox.addButton(
            self.tr("Find"), QDialogButtonBox.ActionRole)
        self.findButton.setEnabled(False)
        self.findButton.setDefault(True)
        
        self.findHistory = []
        self.havefound = False
        
        msh = self.minimumSizeHint()
        self.resize(max(self.width(), msh.width()), msh.height())

    def on_findtextCombo_editTextChanged(self, txt):
        """
        Private slot to enable/disable the find buttons.
        
        @param txt text of the combo box
        @type str
        """
        self.findButton.setEnabled(txt != "")

    def on_buttonBox_clicked(self, button):
        """
        Private slot called by a button of the button box clicked.
        
        @param button button that was clicked
        @type QAbstractButton
        """
        if button == self.findButton:
            self.on_findButton_clicked()
        
    @pyqtSlot()
    def on_findButton_clicked(self):
        """
        Private slot to find the entered text in the displayed page.
        """
        txt = self.findtextCombo.currentText()
        
        # This moves any previous occurrence of this statement to the head
        # of the list and updates the combobox
        if txt in self.findHistory:
            self.findHistory.remove(txt)
        self.findHistory.insert(0, txt)
        self.findtextCombo.clear()
        self.findtextCombo.addItems(self.findHistory)
        
        self.__findNextPrev(self.backwardsButton.isChecked())

    def __findNextPrev(self, backwards):
        """
        Private slot to find the next occurrence of text.
        
        @param backwards flag indicating a backwards search
        @type bool
        """
        if not self.havefound or self.findtextCombo.currentText() == "":
            self.showFind()
            return
        
        if not self.parent().findNextPrev(
                self.findtextCombo.currentText(),
                self.caseCheckBox.isChecked(),
                self.wordCheckBox.isChecked(),
                backwards):
            E5MessageBox.information(
                self, self.windowTitle(),
                self.tr("'{0}' was not found.").format(
                    self.findtextCombo.currentText()))

    def findNext(self):
        """
        Public slot to find the next occurrence.
        """
        self.__findNextPrev(False)

    def findPrevious(self):
        """
        Public slot to find the previous occurrence.
        """
        self.__findNextPrev(True)

    def showFind(self):
        """
        Public method to display this dialog.
        """
        self.havefound = True
        
        self.findtextCombo.clear()
        self.findtextCombo.addItems(self.findHistory)
        self.findtextCombo.setEditText('')
        self.findtextCombo.setFocus()
        
        self.caseCheckBox.setChecked(False)
        self.wordCheckBox.setChecked(False)
        self.forwardButton.setChecked(True)
        
        cur = self.parent().helpWidget().textCursor()
        if cur.hasSelection():
            self.findtextCombo.setEditText(cur.selectedText())
        
        self.show()
