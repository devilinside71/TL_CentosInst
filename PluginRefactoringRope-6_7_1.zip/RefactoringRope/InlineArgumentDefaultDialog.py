# -*- coding: utf-8 -*-

# Copyright (c) 2010 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing the Inline Argument Default dialog.
"""

from __future__ import unicode_literals

from PyQt5.QtCore import pyqtSlot, Qt
from PyQt5.QtWidgets import QDialogButtonBox, QListWidgetItem, QAbstractButton

from .Ui_InlineArgumentDefaultDialog import Ui_InlineArgumentDefaultDialog
from .RefactoringDialogBase import RefactoringDialogBase


class InlineArgumentDefaultDialog(RefactoringDialogBase,
                                  Ui_InlineArgumentDefaultDialog):
    """
    Class implementing the Inline Argument Default dialog.
    """
    NameRole = Qt.UserRole
    
    def __init__(self, refactoring, title, filename, offset, parent=None):
        """
        Constructor
        
        @param refactoring reference to the main refactoring object
        @type RefactoringServer
        @param title title of the dialog
        @type str
        @param filename file name to be worked on
        @type str
        @param offset offset within file
        @type int or None
        @param parent reference to the parent widget
        @type QWidget
        """
        RefactoringDialogBase.__init__(self, refactoring, title, parent)
        self.setupUi(self)
        
        self._changeGroupName = "ChangeSignature"
        
        self.__filename = filename
        self.__offset = offset
        
        self.__definition_info = []
        
        self.__okButton = self.buttonBox.button(QDialogButtonBox.Ok)
        self.__okButton.setEnabled(False)
        self.__previewButton = self.buttonBox.addButton(
            self.tr("Preview"), QDialogButtonBox.ActionRole)
        self.__previewButton.setDefault(True)
        self.__previewButton.setEnabled(False)
        
        self._refactoring.sendJson("RequestSignature", {
            "ChangeGroup": self._changeGroupName,
            "Title": self._title,
            "FileName": self.__filename,
            "Offset": self.__offset,
        })
    
    def __processSignature(self, data):
        """
        Private method to process the inline type data sent by the refactoring
        client in order to polish the dialog.
        
        @param data dictionary containing the inline type data
        @type dict
        """
        self.__definition_info = data["DefinitionInfo"]
        
        # populate the parameters list
        for arg, default in self.__definition_info:
            if default is not None:
                itm = QListWidgetItem("{0}={1}".format(arg, default),
                                      self.parameterList)
                itm.setData(InlineArgumentDefaultDialog.NameRole, arg)
    
    @pyqtSlot()
    def on_parameterList_itemSelectionChanged(self):
        """
        Private slot called, when the selection changes.
        """
        enable = len(self.parameterList.selectedItems()) > 0
        
        self.__okButton.setEnabled(enable)
        self.__previewButton.setEnabled(enable)
    
    @pyqtSlot(QAbstractButton)
    def on_buttonBox_clicked(self, button):
        """
        Private slot to act on the button pressed.
        
        @param button reference to the button pressed
        @type QAbstractButton
        """
        if button == self.__previewButton:
            self.requestPreview()
        elif button == self.__okButton:
            self.applyChanges()
    
    def __getParameterIndex(self, definition_info, name):
        """
        Private method to calculate the index of the given paramter.
        
        @param definition_info list of lists containing the method signature
            definition
        @type list of lists of two str
        @param name parameter name
        @type str
        @return index of the parameter
        @rtype int
        """
        for index, pair in enumerate(definition_info):
            if pair[0] == name:
                return index

    def _calculateChanges(self):
        """
        Protected method to initiate the calculation of the changes.
        """
        items = self.parameterList.selectedItems()
        if len(items) > 0:
            itm = items[0]
            name = itm.data(InlineArgumentDefaultDialog.NameRole)
            index = self.__getParameterIndex(self.__definition_info, name)
            
            self._refactoring.sendJson(
                "CalculateInlineArgumentDefaultChanges", {
                    "ChangeGroup": self._changeGroupName,
                    "Title": self._title,
                    "FileName": self.__filename,
                    "Offset": self.__offset,
                    "Index": index,
                })
    
    def processChangeData(self, data):
        """
        Public method to process the change data sent by the refactoring
        client.
        
        @param data dictionary containing the change data
        @type dict
        """
        subcommand = data["Subcommand"]
        if subcommand == "Signature":
            self.__processSignature(data)
        else:
            # pass on to base class
            RefactoringDialogBase.processChangeData(self, data)
