# -*- coding: utf-8 -*-

# Copyright (c) 2010 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing the Confirmation dialog.
"""

from __future__ import unicode_literals

from PyQt5.QtCore import pyqtSlot
from PyQt5.QtWidgets import QDialogButtonBox, QAbstractButton

from .Ui_ConfirmationDialog import Ui_ConfirmationDialog
from .RefactoringDialogBase import RefactoringDialogBase

import Utilities


class ConfirmationDialog(RefactoringDialogBase, Ui_ConfirmationDialog):
    """
    Class implementing the Confirmation dialog.
    """
    def __init__(self, refactoring, title, changeGroupName, method, parameters,
                 parent=None):
        """
        Constructor
        
        @param refactoring reference to the main refactoring object
        @type RefactoringServer
        @param title title of the dialog
        @type str
        @param changeGroupName name of the change group
        @type str
        @param method method to produce the refactoring changes
        @type str
        @param parameters dictionary containing the method parameters
        @type dict
        @param parent reference to the parent widget
        @type QWidget
        """
        RefactoringDialogBase.__init__(self, refactoring, title, parent)
        self.setupUi(self)
        
        self._changeGroupName = changeGroupName
        
        self.__okButton = self.buttonBox.button(QDialogButtonBox.Ok)
        self.__previewButton = self.buttonBox.addButton(
            self.tr("Preview"), QDialogButtonBox.ActionRole)
        self.__previewButton.setDefault(True)
        
        self.__method = method
        self.__parameters = parameters
        
        self._calculateChanges()
    
    def __processChangeDescription(self, data):
        """
        Private method to process the change description data sent by the
        refactoring client in order to polish the dialog.
        
        @param data dictionary containing the data
        @type dict
        """
        changeDescription = data["Description"]
        if changeDescription:
            self.description.setText(
                self.tr("Shall the refactoring <b>{0}</b> be done?")
                    .format(Utilities.html_encode(changeDescription)))
        else:
            self.description.setText(
                self.tr("The selected refactoring did not produce any"
                        " changes."))
            self.__okButton.setEnabled(False)
            self.__previewButton.setEnabled(False)
        
        msh = self.minimumSizeHint()
        self.resize(max(self.width(), msh.width()), msh.height())
    
    @pyqtSlot(QAbstractButton)
    def on_buttonBox_clicked(self, button):
        """
        Private slot to act on the button pressed.
        
        @param button reference to the button pressed
        @type QAbstractButton
        """
        if button == self.__previewButton:
            self.requestPreview()
        elif button == self.__okButton:
            self.applyChanges()
    
    def _calculateChanges(self):
        """
        Protected method to initiate the calculation of the changes.
        """
        if "ChangeGroup" not in self.__parameters:
            self.__parameters["ChangeGroup"] = self._changeGroupName
        if "Title" not in self.__parameters:
            self.__parameters["Title"] = self._title
        
        self._refactoring.sendJson(self.__method, self.__parameters)
    
    def processChangeData(self, data):
        """
        Public method to process the change data sent by the refactoring
        client.
        
        @param data dictionary containing the change data
        @type dict
        """
        subcommand = data["Subcommand"]
        if subcommand == "ChangeDescription":
            self.__processChangeDescription(data)
        else:
            # pass on to base class
            RefactoringDialogBase.processChangeData(self, data)
