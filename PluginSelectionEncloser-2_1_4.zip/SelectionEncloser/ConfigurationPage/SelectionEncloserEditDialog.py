# -*- coding: utf-8 -*-

# Copyright (c) 2014 - 2017 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing a dialog to edit an enclosing menu entry.
"""

from __future__ import unicode_literals

from PyQt5.QtCore import pyqtSlot
from PyQt5.QtWidgets import QDialog, QDialogButtonBox

from .Ui_SelectionEncloserEditDialog import Ui_SelectionEncloserEditDialog


class SelectionEncloserEditDialog(QDialog, Ui_SelectionEncloserEditDialog):
    """
    Class implementing a dialog to edit an enclosing menu entry.
    """
    def __init__(self, title="", string="", parent=None):
        """
        Constructor
        
        @param title menu entry title (string)
        @param string enclosing string or string format expression (string)
        @param parent reference to the parent widget (QWidget)
        """
        super().__init__(parent)
        self.setupUi(self)
        
        self.titleEdit.setText(title)
        self.stringEdit.setText(string)
        
        msh = self.minimumSizeHint()
        self.resize(max(self.size().width(), msh.width()), msh.height())
        
        self.__updateOkButton()
    
    def __updateOkButton(self):
        """
        Private slot to set the status of the OK button.
        """
        self.buttonBox.button(QDialogButtonBox.Ok).setEnabled(
            bool(self.titleEdit.text()) and bool(self.stringEdit.text()))
    
    @pyqtSlot(str)
    def on_titleEdit_textChanged(self, txt):
        """
        Private slot to react on changes of the title.
        
        @param txt title text (string)
        """
        self.__updateOkButton()
    
    @pyqtSlot(str)
    def on_stringEdit_textChanged(self, txt):
        """
        Private slot to react on changes of the string.
        
        @param txt enclosing string (string)
        """
        self.__updateOkButton()
    
    def getData(self):
        """
        Public method to get the dialog data.
        
        @return tuple with menu entry title (string) and enclosing string
            or string format expression (string)
        """
        return self.titleEdit.text(), self.stringEdit.text()
