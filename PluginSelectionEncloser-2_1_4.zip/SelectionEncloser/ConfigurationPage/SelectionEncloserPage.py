# -*- coding: utf-8 -*-

# Copyright (c) 2014 - 2017 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module implementing Selection Encloser configuration page.
"""

from __future__ import unicode_literals

import os

from PyQt5.QtCore import pyqtSlot, Qt
from PyQt5.QtWidgets import QTreeWidgetItem, QInputDialog, QLineEdit, QDialog

from Preferences.ConfigurationPages.ConfigurationPageBase import \
    ConfigurationPageBase
from .Ui_SelectionEncloserPage import Ui_SelectionEncloserPage

import UI.PixmapCache


class SelectionEncloserPage(ConfigurationPageBase, Ui_SelectionEncloserPage):
    """
    Class implementing Selection Encloser configuration page.
    """
    def __init__(self, plugin):
        """
        Constructor
        
        @param plugin reference to the plugin object
        """
        super(SelectionEncloserPage, self).__init__()
        self.setupUi(self)
        self.setObjectName("SelectionEncloserPage")
        
        self.editButton.setIcon(UI.PixmapCache.getIcon(
            os.path.join("SelectionEncloser", "icons", "edit.png")))
        self.addButton.setIcon(UI.PixmapCache.getIcon("plus.png"))
        self.deleteButton.setIcon(UI.PixmapCache.getIcon("minus.png"))
        self.upButton.setIcon(UI.PixmapCache.getIcon("1uparrow.png"))
        self.downButton.setIcon(UI.PixmapCache.getIcon("1downarrow.png"))
        self.addMenuButton.setIcon(UI.PixmapCache.getIcon(
            os.path.join("SelectionEncloser", "icons", "topAdd.png")))
        self.addSeparatorButton.setIcon(UI.PixmapCache.getIcon(
            os.path.join("SelectionEncloser", "icons", "separatorAdd.png")))
        
        self.editButton.setEnabled(False)
        self.addButton.setEnabled(False)
        self.addSeparatorButton.setEnabled(False)
        self.deleteButton.setEnabled(False)
        self.upButton.setEnabled(False)
        self.downButton.setEnabled(False)
        
        self.__plugin = plugin
        
        # set initial values
        hierarchy = self.__plugin.getPreferences("MenuHierarchy")
        for menuTitle, entries in hierarchy:
            if menuTitle == '--Separator--':
                menuTitle = self.tr('--Separator--')
            top = QTreeWidgetItem(self.menuTree, [menuTitle])
            for title, encString in entries:
                if title == '--Separator--':
                    title = self.tr('--Separator--')
                itm = QTreeWidgetItem(top, [title])
                itm.setData(0, Qt.UserRole, encString)
            top.setExpanded(True)
    
    def save(self):
        """
        Public slot to save the Selection Encloser configuration.
        """
        hierarchy = []
        for topIndex in range(self.menuTree.topLevelItemCount()):
            topItem = self.menuTree.topLevelItem(topIndex)
            menuTitle = topItem.text(0)
            if menuTitle == self.tr('--Separator--'):
                menuTitle = '--Separator--'
            topEntry = [menuTitle, []]
            for index in range(topItem.childCount()):
                itm = topItem.child(index)
                title = itm.text(0)
                if title == self.tr('--Separator--'):
                    title = '--Separator--'
                topEntry[1].append([title, itm.data(0, Qt.UserRole)])
            hierarchy.append(topEntry)
        self.__plugin.setPreferences("MenuHierarchy", hierarchy)
    
    @pyqtSlot()
    def on_addMenuButton_clicked(self):
        """
        Private slot to add a top level menu item.
        """
        menuTitle, ok = QInputDialog.getText(
            self,
            self.tr("Menu Title"),
            self.tr("Enter menu title:"),
            QLineEdit.Normal)
        if ok and menuTitle:
            top = QTreeWidgetItem(self.menuTree, [menuTitle])
            top.setExpanded(True)
    
    @pyqtSlot()
    def on_addButton_clicked(self):
        """
        Private slot to add a menu entry.
        """
        from .SelectionEncloserEditDialog import SelectionEncloserEditDialog
        dlg = SelectionEncloserEditDialog(parent=self)
        if dlg.exec_() == QDialog.Accepted:
            title, encString = dlg.getData()
            itm = QTreeWidgetItem(self.menuTree.selectedItems()[0], [title])
            itm.setData(0, Qt.UserRole, encString)
    
    @pyqtSlot()
    def on_addSeparatorButton_clicked(self):
        """
        Private slot to add a separator entry below the selected entry.
        """
        selItm = self.menuTree.selectedItems()[0]
        parent = selItm.parent()
        itm = QTreeWidgetItem([self.tr('--Separator--')])
        if parent is None:
            # top level item
            index = self.menuTree.indexOfTopLevelItem(selItm) + 1
            self.menuTree.insertTopLevelItem(index, itm)
        else:
            # sub item
            index = parent.indexOfChild(selItm) + 1
            parent.insertChild(index, itm)
    
    @pyqtSlot()
    def on_deleteButton_clicked(self):
        """
        Private slot to delete the selected entry.
        """
        itm = self.menuTree.selectedItems()[0]
        parent = itm.parent()
        if parent is None:
            index = self.menuTree.indexOfTopLevelItem(itm)
            self.menuTree.takeTopLevelItem(index)
        else:
            index = parent.indexOfChild(itm)
            parent.takeChild(index)
        del itm
    
    @pyqtSlot()
    def on_upButton_clicked(self):
        """
        Private slot to move an entry up.
        """
        self.__moveSelectedEntry(True)
    
    @pyqtSlot()
    def on_downButton_clicked(self):
        """
        Private slot to move an entry down.
        """
        self.__moveSelectedEntry(False)
    
    def __moveSelectedEntry(self, moveUp):
        """
        Private method to move the selected entry up or down.
        
        @param moveUp flag indicating to move the entry up (boolean)
        """
        itm = self.menuTree.selectedItems()[0]
        parent = itm.parent()
        if parent is None:
            # top level item
            index = self.menuTree.indexOfTopLevelItem(itm)
            newIndex = index - 1 if moveUp else index + 1
            self.menuTree.takeTopLevelItem(index)
            self.menuTree.insertTopLevelItem(newIndex, itm)
            itm.setExpanded(True)
        else:
            # sub item
            index = parent.indexOfChild(itm)
            newIndex = index - 1 if moveUp else index + 1
            parent.takeChild(index)
            parent.insertChild(newIndex, itm)
        for sitm in self.menuTree.selectedItems():
            sitm.setSelected(False)
        itm.setSelected(True)
    
    @pyqtSlot()
    def on_editButton_clicked(self):
        """
        Private slot to edit the selected entry.
        """
        itm = self.menuTree.selectedItems()[0]
        parent = itm.parent()
        if parent is None:
            menuTitle, ok = QInputDialog.getText(
                self,
                self.tr("Menu Entry"),
                self.tr("Enter menu entry text:"),
                QLineEdit.Normal,
                itm.text(0))
            if ok and menuTitle:
                itm.setText(0, menuTitle)
        else:
            from .SelectionEncloserEditDialog import \
                SelectionEncloserEditDialog
            dlg = SelectionEncloserEditDialog(
                itm.text(0), itm.data(0, Qt.UserRole), self)
            if dlg.exec_() == QDialog.Accepted:
                title, encString = dlg.getData()
                itm.setText(0, title)
                itm.setData(0, Qt.UserRole, encString)
    
    @pyqtSlot()
    def on_menuTree_itemSelectionChanged(self):
        """
        Private slot handling the selection of an item.
        """
        if len(self.menuTree.selectedItems()) == 0:
            self.addButton.setEnabled(False)
            self.addSeparatorButton.setEnabled(False)
            self.deleteButton.setEnabled(False)
            self.upButton.setEnabled(False)
            self.downButton.setEnabled(False)
            self.editButton.setEnabled(False)
        else:
            addEnable = True
            upEnable = True
            downEnable = True
            itm = self.menuTree.selectedItems()[0]
            parent = itm.parent()
            if parent is None:
                # top level item
                if self.menuTree.indexOfTopLevelItem(itm) == 0:
                    upEnable = False
                if self.menuTree.indexOfTopLevelItem(itm) == \
                        self.menuTree.topLevelItemCount() - 1:
                    downEnable = False
            else:
                # sub item
                if parent.indexOfChild(itm) == 0:
                    upEnable = False
                if parent.indexOfChild(itm) == \
                        parent.childCount() - 1:
                    downEnable = False
                addEnable = False
            self.addButton.setEnabled(addEnable)
            self.addSeparatorButton.setEnabled(True)
            self.deleteButton.setEnabled(True)
            self.upButton.setEnabled(upEnable)
            self.downButton.setEnabled(downEnable)
            self.editButton.setEnabled(itm.text(0) != self.tr("--Separator--"))
