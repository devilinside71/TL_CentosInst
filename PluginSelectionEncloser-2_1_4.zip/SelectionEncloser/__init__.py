# -*- coding: utf-8 -*-

# Copyright (c) 2014 - 2017 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Package implementing the Selection Encloser plug-in data and configuration
dialog.
"""
